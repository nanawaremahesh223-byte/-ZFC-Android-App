BUNNY HONEY Android starter project
Open this folder in Android Studio, let Gradle sync, and build an APK.
The included catalog, prices, and COD order are demonstration-only.
No server, payment, or actual order submission is configured.
